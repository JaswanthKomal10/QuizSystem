<?php
/*
 V5.20dev  ??-???-2014  (c) 2000-2014 John Lim (jlim#natsoft.com). All rights reserved.
  Released under both BSD license and Lesser GPL library license.
  Whenever there is any discrepancy between the two licenses,
  the BSD license will take precedence.
  Set tabs to 4.

  NOTE: Since 3.31, this file is no longer used, and the "postgres" driver is
  remapped to "postgres7". Maintaining multiple postgres drivers is no easy
  job, so hopefully this will ensure greater consistency and fewer bugs.
*/
